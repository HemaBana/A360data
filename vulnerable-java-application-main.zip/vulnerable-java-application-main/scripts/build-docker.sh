#!/bin/bash

docker build . -t domain-tester-service