package com.datadoghq.workshops.samplevulnerablejavaapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleVulnerableJavaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleVulnerableJavaAppApplication.class, args);
	}

}
