package com.datadoghq.workshops.samplevulnerablejavaapp.exception;

public class DomainTestException extends Exception {
  public DomainTestException(String message) {
    super(message);
  }
}

