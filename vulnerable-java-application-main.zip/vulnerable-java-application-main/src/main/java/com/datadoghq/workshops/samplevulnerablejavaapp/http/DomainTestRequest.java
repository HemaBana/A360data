package com.datadoghq.workshops.samplevulnerablejavaapp.http;

import lombok.Data;

@Data
public class DomainTestRequest {
  public String domainName;
}
